tinyMCE.addI18n('es.pmSimpleUploader', {
    desc:"Subir Archivo al Servidor"
});
